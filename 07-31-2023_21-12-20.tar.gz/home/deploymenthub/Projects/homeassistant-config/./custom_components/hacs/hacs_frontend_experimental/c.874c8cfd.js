const o=(o,s)=>o<s?-1:o>s?1:0,s=(s,e)=>o(s.toLowerCase(),e.toLowerCase());export{s as c,o as s};
