function r(r){return void 0===r||Array.isArray(r)?r:[r]}export{r as e};
