"""Constants for the SNOOZ Noise Maker integration."""

DOMAIN = "snooz"
